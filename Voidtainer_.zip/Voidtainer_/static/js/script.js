var interval;
var tick = 100;
var gload = 0;

function load(){
  if (gload == 0){
   interval = setInterval("load_tick()", 100);
   document.getElementById("load_block").style.opacity='1';
   gload = 1;
  }else{
    tick = 0;
    load_block.style.display='none';
    clearInterval(interval);
  }
}

function load_tick (){
  tick--;
  var load_block = document.getElementById("load_block");
  var load_center = document.getElementById("center_load");
  load_center.style.top = (tick / 2.5) + "%";
  load_block.style.opacity = tick / 100;
  if (tick == 0) {
      load_block.style.display='none';
      clearInterval(interval);
  }
}

function show_password(id, img_id){
   if ($(id).attr('type') == "password"){
       $(id).attr('type', "text");
       $(img_id).attr('src', "/static/img/no_show_password.svg");
   }else {
      $(id).attr('type', "password");
      $(img_id).attr('src', "/static/img/show_password.svg");
   }
}

function close_element(id){
    if ($(id).css('display') == 'none') $(id).css({"display":"block"});
    else $(id).css({"display":"none"});
}

function activate_input(id){
   $(id).click();
}

function set_input(id, value){
   $(id).attr('value', value);
}

function place_at(id, par_id, d_x, d_y){
   el = document.getElementById(par_id)
   let cords = el.getBoundingClientRect();
   $(id).css('left', cords.left + d_x);
   $(id).css('top', cords.top + d_y);
}

function copy_from(copy_text){
  $("#_copy_text").attr('value', copy_text);
  get_text = document.getElementById("_copy_text");
  get_text.select();
  document.execCommand("copy");
}

function if_or_else(if_var, id_true, id_false){
  if (if_var) $(id_true).css('display', 'block');
  else $(id_false).css('display', 'block');
}

function edit_link(id, link){
  $(id).attr('href', link);
}
